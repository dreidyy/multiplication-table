﻿namespace A7_MultiplicationTable
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lbnumber = new System.Windows.Forms.Label();
            this.tbnumber = new System.Windows.Forms.TextBox();
            this.btmultiply = new System.Windows.Forms.Button();
            this.lbTable = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbnumber
            // 
            this.lbnumber.AutoSize = true;
            this.lbnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnumber.ForeColor = System.Drawing.Color.White;
            this.lbnumber.Location = new System.Drawing.Point(53, 47);
            this.lbnumber.Name = "lbnumber";
            this.lbnumber.Size = new System.Drawing.Size(125, 20);
            this.lbnumber.TabIndex = 0;
            this.lbnumber.Text = "Enter Number:";
            // 
            // tbnumber
            // 
            this.tbnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbnumber.Location = new System.Drawing.Point(184, 47);
            this.tbnumber.Multiline = true;
            this.tbnumber.Name = "tbnumber";
            this.tbnumber.Size = new System.Drawing.Size(112, 28);
            this.tbnumber.TabIndex = 1;
            this.tbnumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbnumber.MouseEnter += new System.EventHandler(this.tbnumber_MouseEnter);
            // 
            // btmultiply
            // 
            this.btmultiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmultiply.ForeColor = System.Drawing.Color.Black;
            this.btmultiply.Image = ((System.Drawing.Image)(resources.GetObject("btmultiply.Image")));
            this.btmultiply.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btmultiply.Location = new System.Drawing.Point(113, 110);
            this.btmultiply.Name = "btmultiply";
            this.btmultiply.Size = new System.Drawing.Size(127, 34);
            this.btmultiply.TabIndex = 2;
            this.btmultiply.Text = "Multiply";
            this.btmultiply.UseVisualStyleBackColor = true;
            this.btmultiply.Click += new System.EventHandler(this.btmultiply_Click);
            // 
            // lbTable
            // 
            this.lbTable.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTable.FormattingEnabled = true;
            this.lbTable.ItemHeight = 20;
            this.lbTable.Location = new System.Drawing.Point(70, 217);
            this.lbTable.Name = "lbTable";
            this.lbTable.Size = new System.Drawing.Size(226, 224);
            this.lbTable.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(53, 183);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Multiplication Table";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(362, 465);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbTable);
            this.Controls.Add(this.btmultiply);
            this.Controls.Add(this.tbnumber);
            this.Controls.Add(this.lbnumber);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Multiplication Table (TryParse)";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbnumber;
        private System.Windows.Forms.TextBox tbnumber;
        private System.Windows.Forms.Button btmultiply;
        private System.Windows.Forms.ListBox lbTable;
        private System.Windows.Forms.Label label1;
    }
}

