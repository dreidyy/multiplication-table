﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A7_MultiplicationTable
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }

        private void btmultiply_Click(object sender, EventArgs e)
        {
            int number = 0;

            if (int.TryParse(tbnumber.Text, out number))
            {

                for (int a = 1; a <= 10; a++)
                {
                  lbTable.Items.Add(number + " * " + a + "\n = " + number * a );
                }

            } else
                {
                    MessageBox.Show("Enter numbers only");
                }

            //int number = 0;
            //for (a = 1; a <= 10; a++)
            //{
            // lbTable.Items.Add(number + " * " + a + "\n = " + number * a);
            //} else{
            //  MessageBox.Show("Enter Numbers only");
            //}

        }

        private void tbnumber_MouseEnter(object sender, EventArgs e)
        {
            lbTable.Items.Clear();
            tbnumber.Clear();
        }
    }
}
